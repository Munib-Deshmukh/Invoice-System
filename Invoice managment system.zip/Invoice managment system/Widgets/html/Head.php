<head>
    <title>Invoise System</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="Widgets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="Widgets/css/custom.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
</head>
