<div class="container">
    <div class="container">
        <header class="nav container-fluid">
            <h3 class="navbar-brand">Invoice</h3>
        </header>
    </div>
                <div class="container-fluid">
                  <div class="col-sm-5">
                      <div class="table-responsive" id="Invoice">
                          <table class="table table-bordered" id="T" style=" width: 100% !important;">
                              <thead>
                                  <tr>
                                        <th>order_id</th>
                                        <th>invoice_name</th>
                                        <th>Total_Amount</th>
                                  </tr>
                              </thead>
                              <tfoot>
                                  <tr>
                                      <th>order_id</th>
                                      <th>invoice_name</th>
                                      <th>Total_Amount</th>
                                  </tr>
                              </tfoot>
                          </table>
                      </div>
                  </div>
                  <div class="col-sm-7">
                      <div class="table-responsive" id="Invoice_detail">
                          <table class="table table-bordered" id="T2" >
                              <thead>
                                  <tr>
                                        <th>ID</th>
                                        <th>Invoice ID</th>
                                        <th>Product Name</th>
                                        <th>Qantitiy</th>
                                        <th>Price</th>
                                        <th>Discount</th>
                                        <th>Amount</th>
                                  </tr>
                              </thead>
                              <tfoot>
                                  <tr>
                                      <th>ID</th>
                                      <th>Invoice ID</th>
                                      <th>Product Name</th>
                                      <th>Qantitiy</th>
                                      <th>Price</th>
                                      <th>Discount</th>
                                      <th>Amount</th>
                                  </tr>
                              </tfoot>
                          </table>
                      </div>
                  </div>
                </div>

    </div>
</div>
