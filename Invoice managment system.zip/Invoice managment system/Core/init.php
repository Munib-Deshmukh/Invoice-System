<?php
session_start();

require 'Includes/connect.inc.php';
require 'Includes/general.php';
require 'Includes/user.php';
?>