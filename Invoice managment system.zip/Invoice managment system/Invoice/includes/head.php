<head>
    <title>Invoise System</title>
    <meta charset="utf-8">
    <link rel="stylesheet" type="text/css" href="Widgets/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="Widgets/css/custom2.css">
    <link rel="stylesheet" type="text/css" href="Widgets/css/Datatable.css">
    <link rel="stylesheet" type="text/css" href="Widgets/css/tabletools.css">
    <script src="Widgets/js/Jquery.js"></script>
    <script src="Widgets/js/bootstrap.min.js"></script>
    <script src="Widgets/js/invoicescript.js"></script>
    <script type="text/javascript" src="Widgets/js/retrive_invoice.js"></script>
    <script src="Widgets/js/Datatable.js"></script>
    <script>

    </script>
    <script src="Widgets/js/tabletools.js"></script>

</head>